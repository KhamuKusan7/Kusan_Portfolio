<?php
/**
 * Plugin Name: Direct buy single product
 * Plugin URI: https://aashishkhambu.com.np/plugin/direct-buy-single-product/
 * Description: Adds an Amazon-style "Buy Now" button to WooCommerce product pages. Sends users directly to checkout without affecting cart items.
 * Version: 1.0
 * Author: Aashish Khambu
 * Author URI: https://aashishkhambu.com.np/
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: direct-buy-single-product
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Buy_Now_Button_For_WooCommerce {

    public function __construct() {
        add_action( 'woocommerce_after_add_to_cart_button', [ $this, 'render_button' ], 20 );
        add_action( 'wp_footer', [ $this, 'enqueue_script' ] );
        add_action( 'wp_ajax_buy_now_trigger', [ $this, 'handle_ajax' ] );
        add_action( 'wp_ajax_nopriv_buy_now_trigger', [ $this, 'handle_ajax' ] );
        add_action( 'template_redirect', [ $this, 'maybe_switch_cart' ] );
        add_action( 'woocommerce_thankyou', [ $this, 'restore_cart' ] );
    }

    public function render_button() {
        global $product;
        if ( is_product() && $product->is_type( 'simple' ) ) {
            echo '<button class="buy-now-button" data-product_id="' . esc_attr( $product->get_id() ) . '" style="margin-top:10px;">Buy Now</button>';
        }
    }

    public function enqueue_script() {
        if ( ! is_product() ) return;
        ?>
        <script>
        jQuery(document).ready(function($){
            $('.buy-now-button').on('click', function(){
                var productId = $(this).data('product_id');
                $.post('<?php echo admin_url( 'admin-ajax.php' ); ?>', {
                    action: 'buy_now_trigger',
                    product_id: productId
                }, function(response){
                    if (response.success && response.data.url) {
                        window.location.href = response.data.url;
                    } else {
                        alert('Error: Could not initiate Buy Now.');
                    }
                });
            });
        });
        </script>
        <?php
    }

    public function handle_ajax() {
        if ( empty( $_POST['product_id'] ) ) wp_send_json_error();

        $product_id = absint( $_POST['product_id'] );
        $cart_items = WC()->cart->get_cart();

        setcookie( 'buy_now_cart_backup', base64_encode( serialize( $cart_items ) ), time() + 300, COOKIEPATH, COOKIE_DOMAIN );
        WC()->session->set( 'buy_now_product_id', $product_id );

        $checkout_url = wc_get_checkout_url();
        $checkout_url = add_query_arg( 'buy_now', 1, $checkout_url );

        wp_send_json_success( [ 'url' => $checkout_url ] );
    }

    public function maybe_switch_cart() {
        if ( isset($_GET['buy_now']) && WC()->session->get('buy_now_product_id') ) {
            $product_id = WC()->session->get('buy_now_product_id');
            WC()->cart->empty_cart();
            WC()->cart->add_to_cart( $product_id, 1 );
        }
    }

    public function restore_cart( $order_id ) {
        if ( isset( $_COOKIE['buy_now_cart_backup'] ) ) {
            $cart_data = unserialize( base64_decode( $_COOKIE['buy_now_cart_backup'] ) );
            WC()->cart->empty_cart();

            foreach ( $cart_data as $item ) {
                WC()->cart->add_to_cart(
                    $item['product_id'],
                    $item['quantity'],
                    isset($item['variation_id']) ? $item['variation_id'] : 0,
                    isset($item['variation']) ? $item['variation'] : array(),
                    isset($item['cart_item_data']) ? $item['cart_item_data'] : array()
                );
            }

            setcookie( 'buy_now_cart_backup', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN );
            WC()->session->__unset( 'buy_now_product_id' );
        }
    }
}

new Buy_Now_Button_For_WooCommerce();
