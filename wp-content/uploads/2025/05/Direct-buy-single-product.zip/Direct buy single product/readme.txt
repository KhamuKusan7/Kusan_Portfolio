=== direct buy single product ===
Contributors: Aashish Khambu
Tags: buy now, checkout, cart restoration, ecommerce
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0
License: GPL2

A WooCommerce plugin that adds an Amazon-style "Buy Now" button with cart restoration and premium features.

== Description ==
Buy Now Button Pro lets your customers buy a product instantly, skipping the cart and going straight to checkout. It backs up the cart and restores it if checkout is not completed — just like Amazon's "Buy Now."

**Features:**
- Adds a "Buy Now" button on product pages
- Redirects straight to checkout
- Cart is cleared for fast checkout
- Restores cart if checkout is not completed
- Stylish default button
- Simple product support
- Lightweight and fast

== Installation ==
1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu.
3. Visit any WooCommerce product page to see the "Buy Now" button.

== Frequently Asked Questions ==

= Does this work with variable products? =
Not yet, but support for that is coming in a future update.

= Can I customize the button? =
 customizable options will be available soon.

== Screenshots ==
1. "Buy Now" button on product page
2. Redirecting to checkout after clicking
3. Cart restored automatically if checkout abandoned

== Changelog ==
= 1.0.0 =
* Initial release with cart backup/restore
* Direct-to-checkout functionality
* Basic styling for the button